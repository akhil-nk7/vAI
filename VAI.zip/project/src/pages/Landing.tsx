import React from 'react';
import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import ChatCTA from '../components/ChatCTA';
import HowItWorks from '../components/HowItWorks';
import UpcomingFeatures from '../components/UpcomingFeatures';
import FAQs from '../components/FAQs';
import Footer from '../components/Footer';

const Landing: React.FC = () => {
  return (
    <div className="font-sans text-neutral-800 bg-neutral-50">
      <Navbar />
      <main>
        <Hero />
        <ChatCTA />
        <HowItWorks />
        <UpcomingFeatures />
        <FAQs />
      </main>
      <Footer />
    </div>
  );
};

export default Landing;