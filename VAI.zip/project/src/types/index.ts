export interface NavItem {
  label: string;
  href: string;
}

export interface FAQItem {
  question: string;
  answer: string;
}

export interface FeatureTile {
  id: number;
  title: string;
  description: string;
  icon: string;
}

export interface ChatMessage {
  id: number;
  text: string;
  isUser: boolean;
}