import React from 'react';
import { Bot } from 'lucide-react';
import { Link } from 'react-router-dom';

const Hero: React.FC = () => {
  return (
    <section className="pt-28 pb-16 md:pt-32 md:pb-24">
      <div className="container mx-auto px-4 md:px-6">
        <div className="relative max-w-3xl mx-auto text-center">
          <div className="absolute -top-20 -left-4 md:-left-24 opacity-20">
            <Bot className="w-40 h-40 text-primary-300" />
          </div>
          <div className="absolute -bottom-20 -right-4 md:-right-24 opacity-20">
            <Bot className="w-40 h-40 text-secondary-300" />
          </div>
          
          <h1 className="font-display text-3xl md:text-5xl font-bold text-neutral-900 leading-tight mb-6">
            <div className="flex justify-center items-center gap-2">
              <span className="text-primary-600">Healing</span> Minds.
              <span className="text-secondary-600">Guiding</span> Health.
            </div>
            <div>Powered by AI.</div>
          </h1>
          
          <p className="text-lg md:text-xl text-neutral-700 mb-8 max-w-2xl mx-auto">
            Your personal AI healthcare companion blending the wisdom of Ayurveda 
            with modern medicine for personalized wellness guidance.
          </p>
          
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/chat" className="inline-flex items-center justify-center px-6 py-3 bg-secondary-500 text-white font-medium rounded-full hover:bg-secondary-600 transition-colors duration-300">
              Try vAIdhyan Now
            </Link>
            <a href="#how-it-works" className="inline-flex items-center justify-center px-6 py-3 bg-primary-50 text-primary-700 font-medium rounded-full hover:bg-primary-100 transition-colors duration-300">
              Learn More
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;