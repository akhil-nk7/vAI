import React from 'react';
import { Calendar, Pill } from 'lucide-react';

const UpcomingFeatures: React.FC = () => {
  return (
    <section className="py-16 bg-gradient-to-r from-primary-50 to-secondary-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-lg p-8 md:p-10 border border-neutral-100">
          <h2 className="font-display text-2xl md:text-3xl font-bold text-neutral-900 mb-6 text-center">
            Coming Soon to vAIdhyan
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="flex">
              <div className="flex-shrink-0 mr-4">
                <div className="w-12 h-12 bg-primary-100 text-primary-600 rounded-full flex items-center justify-center">
                  <Calendar className="w-6 h-6" />
                </div>
              </div>
              <div>
                <h3 className="text-lg font-bold text-neutral-900 mb-2">
                  Appointment Booking
                </h3>
                <p className="text-neutral-700">
                  Schedule consultations with Ayurvedic doctors and modern healthcare practitioners directly through the platform.
                </p>
              </div>
            </div>
            
            <div className="flex">
              <div className="flex-shrink-0 mr-4">
                <div className="w-12 h-12 bg-secondary-100 text-secondary-600 rounded-full flex items-center justify-center">
                  <Pill className="w-6 h-6" />
                </div>
              </div>
              <div>
                <h3 className="text-lg font-bold text-neutral-900 mb-2">
                  Medicine Delivery
                </h3>
                <p className="text-neutral-700">
                  Order prescribed Ayurvedic and modern medicines with doorstep delivery for a seamless healthcare experience.
                </p>
              </div>
            </div>
          </div>
          
          <div className="mt-8 text-center">
            <p className="text-neutral-600 italic">
              All your healthcare needs, unified in one intelligent platform.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default UpcomingFeatures;