import React from 'react';
import { MessageCircle, HeartHandshake, Sparkles } from 'lucide-react';
import { FEATURE_TILES } from '../constants';

const iconMap: Record<string, React.ReactNode> = {
  'message-circle': <MessageCircle className="w-8 h-8" />,
  'heart-handshake': <HeartHandshake className="w-8 h-8" />,
  'sparkles': <Sparkles className="w-8 h-8" />
};

const HowItWorks: React.FC = () => {
  return (
    <section id="how-it-works" className="py-16">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="font-display text-2xl md:text-3xl font-bold text-neutral-900 mb-4">
            How vAIdhyan Works
          </h2>
          <p className="text-lg text-neutral-700 max-w-2xl mx-auto">
            Experience the seamless blend of ancient wisdom and modern technology for your health and wellness.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {FEATURE_TILES.map((feature, index) => (
            <div 
              key={feature.id}
              className="bg-white rounded-xl p-6 shadow-md border border-neutral-100 transform transition-transform hover:-translate-y-1 hover:shadow-lg"
            >
              <div className="mb-4 flex justify-center">
                <div className="w-16 h-16 bg-primary-50 text-primary-600 rounded-full flex items-center justify-center">
                  {iconMap[feature.icon]}
                </div>
              </div>
              
              <div className="text-center">
                <div className="inline-block mb-4">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-secondary-500 text-white font-bold">
                    {feature.id}
                  </div>
                </div>
                <h3 className="text-xl font-bold text-neutral-900 mb-2">
                  {feature.title}
                </h3>
                <p className="text-neutral-600">
                  {feature.description}
                </p>
              </div>
            </div>
          ))}
        </div>
        
        <div className="flex justify-center mt-12">
          <a 
            href="#chat"
            className="inline-flex items-center justify-center px-6 py-3 bg-primary-100 text-primary-700 font-medium rounded-full hover:bg-primary-200 transition-colors duration-300"
          >
            Try It Now
          </a>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;