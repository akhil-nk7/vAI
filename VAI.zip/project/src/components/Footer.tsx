import React from 'react';
import Logo from './ui/Logo';
import { Linkedin, Twitter, Facebook, Instagram } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-neutral-50 border-t border-neutral-200">
      <div className="container mx-auto px-4 md:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <Logo className="mb-4" />
            <p className="text-neutral-600 mb-4">
              AI-powered healthcare combining Ayurvedic wisdom with modern medicine.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-neutral-500 hover:text-primary-600 transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-neutral-500 hover:text-primary-600 transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-neutral-500 hover:text-primary-600 transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-neutral-500 hover:text-primary-600 transition-colors">
                <Linkedin size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-medium text-neutral-900 mb-4">Company</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-neutral-600 hover:text-primary-600 transition-colors">About Us</a></li>
              <li><a href="#" className="text-neutral-600 hover:text-primary-600 transition-colors">Careers</a></li>
              <li><a href="#" className="text-neutral-600 hover:text-primary-600 transition-colors">Blog</a></li>
              <li><a href="#" className="text-neutral-600 hover:text-primary-600 transition-colors">Press</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-medium text-neutral-900 mb-4">Resources</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-neutral-600 hover:text-primary-600 transition-colors">Health Articles</a></li>
              <li><a href="#" className="text-neutral-600 hover:text-primary-600 transition-colors">Ayurvedic Guide</a></li>
              <li><a href="#" className="text-neutral-600 hover:text-primary-600 transition-colors">Wellness Tips</a></li>
              <li><a href="#" className="text-neutral-600 hover:text-primary-600 transition-colors">Support Center</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-medium text-neutral-900 mb-4">Legal</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-neutral-600 hover:text-primary-600 transition-colors">Terms of Service</a></li>
              <li><a href="#" className="text-neutral-600 hover:text-primary-600 transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="text-neutral-600 hover:text-primary-600 transition-colors">Cookie Policy</a></li>
              <li><a href="#" className="text-neutral-600 hover:text-primary-600 transition-colors">Data Protection</a></li>
            </ul>
          </div>
        </div>
        
        <div className="mt-12 pt-6 border-t border-neutral-200">
          <p className="text-neutral-500 text-center">
            &copy; {new Date().getFullYear()} vAIdhyan. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;