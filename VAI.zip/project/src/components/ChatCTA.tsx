import React, { useState, useEffect } from 'react';
import { CHAT_MESSAGES } from '../constants';
import { Send } from 'lucide-react';
import { Link } from 'react-router-dom';

const ChatCTA: React.FC = () => {
  const [messages, setMessages] = useState(CHAT_MESSAGES);
  const [isTyping, setIsTyping] = useState(false);

  return (
    <section id="chat" className="py-16 bg-neutral-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="font-display text-2xl md:text-3xl font-bold text-neutral-900 mb-4">
            Experience AI-Powered Healthcare
          </h2>
          <p className="text-lg text-neutral-700 max-w-2xl mx-auto">
            Interact with vAIdhyan for personalized health insights, combining ancient Ayurvedic wisdom with modern medical knowledge.
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto">
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden border border-neutral-200">
            {/* Chat Header */}
            <div className="bg-primary-500 text-white px-6 py-4">
              <div className="flex items-center">
                <div className="w-3 h-3 bg-secondary-300 rounded-full mr-2"></div>
                <h3 className="font-medium">vAIdhyan Health Assistant</h3>
              </div>
            </div>
            
            {/* Chat Messages */}
            <div className="px-6 py-4 h-80 overflow-y-auto bg-neutral-50">
              <div className="space-y-4">
                {messages.map((message) => (
                  <div 
                    key={message.id} 
                    className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
                  >
                    <div 
                      className={`max-w-[80%] px-4 py-3 rounded-2xl ${
                        message.isUser 
                          ? 'bg-primary-100 text-neutral-800 rounded-tr-none' 
                          : 'bg-white shadow-md text-neutral-800 rounded-tl-none border border-neutral-200'
                      }`}
                    >
                      <p className="whitespace-pre-line">{message.text}</p>
                    </div>
                  </div>
                ))}
                
                {isTyping && (
                  <div className="flex justify-start">
                    <div className="bg-white shadow-md px-4 py-3 rounded-2xl rounded-tl-none">
                      <div className="flex space-x-2">
                        <div className="w-2 h-2 bg-neutral-300 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-neutral-300 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                        <div className="w-2 h-2 bg-neutral-300 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            {/* Chat Input */}
            <div className="px-6 py-4 border-t border-neutral-200 bg-white">
              <Link 
                to="/chat"
                className="flex items-center justify-center px-6 py-3 bg-secondary-500 text-white font-medium rounded-full hover:bg-secondary-600 transition-colors w-full"
              >
                Start Chatting with vAIdhyan
              </Link>
            </div>
          </div>
          
          <p className="text-center text-neutral-500 mt-4 text-sm">
            For demonstration purposes only. vAIdhyan provides general wellness information, not medical diagnosis.
          </p>
        </div>
      </div>
    </section>
  );
};

export default ChatCTA;