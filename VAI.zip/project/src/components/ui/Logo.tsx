import React from 'react';
import { Stethoscope } from 'lucide-react';

interface LogoProps {
  className?: string;
}

const Logo: React.FC<LogoProps> = ({ className = '' }) => {
  return (
    <div className={`flex items-center ${className}`}>
      <Stethoscope className="w-8 h-8 text-primary-600 mr-2" />
      <span className="font-display font-bold text-2xl">
        <span className="text-primary-600">v</span>
        <span className="text-secondary-600">AI</span>
        <span className="text-primary-600">dhyan</span>
      </span>
    </div>
  );
};

export default Logo;