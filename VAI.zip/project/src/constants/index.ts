import { NavItem, FAQItem, FeatureTile, ChatMessage } from '../types';

export const NAV_ITEMS: NavItem[] = [
  { label: 'Home', href: '#' },
  { label: 'How It Works', href: '#how-it-works' },
  { label: 'About', href: '#about' },
  { label: 'FAQs', href: '#faqs' },
];

export const FAQ_ITEMS: FAQItem[] = [
  {
    question: 'What is vAIdhyan?',
    answer: 'vAIdhyan is an AI-powered virtual healthcare assistant that combines Ayurvedic wisdom with modern healthcare practices to provide personalized health advice, symptom analysis, and wellness recommendations.'
  },
  {
    question: 'Is my health data secure with vAIdhyan?',
    answer: 'Absolutely. We prioritize your privacy and maintain the highest standards of data security. Your health information is encrypted and never shared with third parties without your explicit consent.'
  },
  {
    question: 'How accurate is the health advice from vAIdhyan?',
    answer: 'vAIdhyan provides information based on established medical knowledge and Ayurvedic principles. While our AI is constantly learning and improving, the advice should complement, not replace, consultation with healthcare professionals for serious conditions.'
  },
  {
    question: 'Will vAIdhyan be available as a mobile app?',
    answer: 'Yes! We are currently developing mobile applications for both iOS and Android platforms to make vAIdhyan accessible wherever you go. Stay tuned for our launch announcement.'
  }
];

export const FEATURE_TILES: FeatureTile[] = [
  {
    id: 1,
    title: 'Talk to the AI',
    description: 'Share your symptoms and health concerns in natural language with our intelligent assistant.',
    icon: 'message-circle'
  },
  {
    id: 2,
    title: 'Get Remedies',
    description: 'Receive personalized Ayurvedic and modern healthcare recommendations for your wellness.',
    icon: 'heart-handshake'
  },
  {
    id: 3,
    title: 'Discover Wellness',
    description: 'Explore holistic approaches to improve your overall health and wellbeing.',
    icon: 'sparkles'
  }
];

export const CHAT_MESSAGES: ChatMessage[] = [
  {
    id: 1,
    text: "I've been having frequent headaches and difficulty sleeping. What could help?",
    isUser: true
  },
  {
    id: 2,
    text: "Based on your symptoms, this could be related to stress or tension. From an Ayurvedic perspective, these symptoms suggest a Vata imbalance. I recommend:\n\n1. Warm oil head massage with brahmi oil\n2. Herbal tea with chamomile and ashwagandha before bed\n3. Regular sleep schedule\n\nWould you like more specific recommendations?",
    isUser: false
  }
];